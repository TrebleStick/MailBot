#ifndef PyObjC_METHOD_ACCESSOR_H
#define PyObjC_METHOD_ACCESSOR_H

extern PyTypeObject PyObjCMethodAccessor_Type;
extern PyObject* PyObjCMethodAccessor_New(PyObject* base, int class_method);

#endif /* PyObjC_METHOD_ACCESSOR_H */

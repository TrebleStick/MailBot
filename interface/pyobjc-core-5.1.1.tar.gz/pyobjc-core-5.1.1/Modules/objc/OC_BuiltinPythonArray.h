#import "pyobjc.h"

@interface OC_BuiltinPythonArray : OC_PythonArray
{
}
@end

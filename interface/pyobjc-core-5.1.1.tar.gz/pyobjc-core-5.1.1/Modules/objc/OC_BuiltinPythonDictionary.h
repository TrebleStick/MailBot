#import "pyobjc.h"

@interface OC_BuiltinPythonDictionary : OC_PythonDictionary
{
}
@end

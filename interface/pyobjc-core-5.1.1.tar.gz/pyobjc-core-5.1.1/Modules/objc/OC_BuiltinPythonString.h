#include "pyobjc.h"

@interface OC_BuiltinPythonString : OC_PythonString
{
}
@end

#import "pyobjc.h"

@interface OC_BuiltinPythonNumber : OC_PythonNumber
{
}
@end

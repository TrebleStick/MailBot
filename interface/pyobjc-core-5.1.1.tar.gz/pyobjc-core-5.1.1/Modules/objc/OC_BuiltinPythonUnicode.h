#import "pyobjc.h"

@interface OC_BuiltinPythonUnicode : OC_PythonUnicode
{
}
@end
